//
//  ClosedSourceFramework.h
//  ClosedSourceFramework
//
//  Created by Gerson Noboa on 3/5/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ClosedSourceFramework.
FOUNDATION_EXPORT double ClosedSourceFrameworkVersionNumber;

//! Project version string for ClosedSourceFramework.
FOUNDATION_EXPORT const unsigned char ClosedSourceFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ClosedSourceFramework/PublicHeader.h>


